<?php

$a = "first";
$b = "second";
$str = $a . ":" . $b;

echo $str;

phpinfo();

?>

<p> paragraph